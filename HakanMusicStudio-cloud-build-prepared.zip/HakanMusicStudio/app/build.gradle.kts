plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hakan.musicstudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hakan.musicstudio"
        minSdk = 26
        targetSdk = 28
        versionCode = 6
        versionName = "1.0.0"
    }
}
