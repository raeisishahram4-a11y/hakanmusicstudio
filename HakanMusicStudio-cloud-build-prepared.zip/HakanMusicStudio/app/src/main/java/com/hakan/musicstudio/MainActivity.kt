package com.hakan.musicstudio

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.database.Cursor
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.provider.OpenableColumns
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaExtractor
import android.media.MediaCodec
import android.media.MediaFormat
import java.nio.ByteOrder
import kotlin.math.roundToInt
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 24, 39)
    private val card = Color.rgb(26, 38, 58)
    private val mint = Color.rgb(189, 231, 207)
    private val white = Color.rgb(243, 246, 251)
    private val playing = AtomicBoolean(false)
    @Volatile private var track: AudioTrack? = null
    @Volatile private var bpm = 120
    @Volatile private var volume = 0.75
    @Volatile private var melodyGain = 0.85
    @Volatile private var bassGain = 0.45
    @Volatile private var drumsGain = 0.35
    @Volatile private var padGain = 0.25
    private var currentMood = "شاد"
    private var rhythmStyle = "پاپ ساده"
    private var melodyInstrument = "همه سازها"
    private var generatedMelody = doubleArrayOf(261.63, 329.63, 392.00, 329.63, 293.66, 329.63, 440.00, 392.00)
    private lateinit var status: TextView
    private lateinit var bpmLabel: TextView
    private var lastBackPress = 0L
    private data class AudioLayer(val uri: Uri, val name: String, var gain: Float = 0.8f, var player: MediaPlayer? = null)
    private val importedLayers = mutableListOf<AudioLayer>()
    private var mixerDialog: AlertDialog? = null
    private var mixerContent: LinearLayout? = null
    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var isRecording = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        restoreAutoProject()
        requestFirstRunPermissionsIfNeeded()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "🎹 Hakan Music Studio"
            textSize = 25f; setTextColor(white); gravity = Gravity.CENTER
        }, match(WRAP))
        root.addView(TextView(this).apply {
            text = "آهنگ‌سازی ساده، مستقیم روی گوشی و بدون اینترنت"
            textSize = 16f; setTextColor(0xFFC7D1E0.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(18))
        }, match(WRAP))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(card)
        }
        panel.addView(TextView(this).apply {
            text = "ملودی آغازین"; textSize = 20f; setTextColor(white); gravity = Gravity.CENTER
        }, match(WRAP))
        panel.addView(TextView(this).apply {
            text = "دو     می     سل     می\nC4     E4     G4     E4"
            textSize = 22f; setTextColor(mint); gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(20))
        }, match(WRAP))
        bpmLabel = TextView(this).apply {
            text = "سرعت: ۱۲۰ ضرب در دقیقه"; textSize = 17f; setTextColor(white)
        }
        panel.addView(bpmLabel, match(WRAP))
        val seek = SeekBar(this).apply { max = 120; progress = (bpm - 60).coerceIn(0, 120); contentDescription = "تنظیم سرعت آهنگ" }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                bpm = progress + 60
                bpmLabel.text = "سرعت: ${bpm.toPersianDigits()} ضرب در دقیقه"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        panel.addView(seek, match(WRAP))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        buttons.addView(Button(this).apply {
            text = "▶ پخش ملودی"; setTextColor(bg); setBackgroundColor(mint)
            setOnClickListener { playMelody() }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(6) })
        buttons.addView(Button(this).apply {
            text = "■ توقف"; setOnClickListener { stopMelody() }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(6) })
        panel.addView(buttons, match(WRAP))
        panel.addView(Button(this).apply {
            text = "✨ ساخت ملودی ساده"
            setOnClickListener { showMelodyBuilder() }
        }, match(dp(52)))
        panel.addView(TextView(this).apply {
            text = "حال‌وهوا: $currentMood"
            tag = "mood_label"
            textSize = 15f; setTextColor(mint); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }, match(WRAP))
        panel.addView(Button(this).apply {
            text = "🥁 انتخاب ریتم"
            setOnClickListener { showRhythmBuilder() }
        }, match(dp(52)))
        panel.addView(Button(this).apply {
            text = "🎹 انتخاب ساز ملودی"
            setOnClickListener { showInstrumentBuilder() }
        }, match(dp(52)))
        panel.addView(TextView(this).apply {
            text = "ریتم: $rhythmStyle   |   سازها: $melodyInstrument"
            tag = "sound_label"
            textSize = 14f; setTextColor(0xFFC7D1E0.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        }, match(WRAP))
        status = TextView(this).apply {
            text = "آمادهٔ پخش"; textSize = 15f; setTextColor(mint); gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }
        panel.addView(status, match(WRAP))
        root.addView(panel, match(WRAP))

        val menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        menu.addView(Button(this).apply {
            text = "🎚 میکس آهنگ"
            setOnClickListener { showMixer() }
        }, match(dp(50)))
        menu.addView(Button(this).apply {
            text = "🎙 ضبط زمزمه یا آواز"
            setOnClickListener { toggleRecording() }
        }, match(dp(50)))
        menu.addView(Button(this).apply {
            text = "💾 ذخیره / بازیابی پروژه"
            setOnClickListener { showProjectMenu() }
        }, match(dp(50)))
        menu.addView(Button(this).apply {
            text = "📦 پشتیبان برای انتقال به گوشی دیگر"
            setOnClickListener { createTransferBackup() }
        }, match(dp(50)))
        menu.addView(Button(this).apply {
            text = "📖 راهنمای کامل برنامه"
            setOnClickListener { showGuide() }
        }, match(dp(50)))
        menu.addView(Button(this).apply {
            text = "⚙ تنظیمات جامع"
            setOnClickListener { showSettings() }
        }, match(dp(50)))
        menu.addView(Button(this).apply {
            text = "خروج از برنامه"
            setOnClickListener { confirmExit() }
        }, match(dp(50)))
        root.addView(menu, match(WRAP))
        root.addView(TextView(this).apply {
            text = "نسخهٔ آزمایشی ۰٫۹ • برای خروج، دکمهٔ بازگشت را دوبار بزنید."
            textSize = 13f; setTextColor(0xFFB5C2D5.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }, match(WRAP))
        setContentView(root)
    }

    private fun showGuide() {
        val guide = """به استودیوی موسیقی هاکان خوش آمدی! 🎵

شروع آسان
• برای شنیدن نمونه، «پخش ملودی» را بزن و سرعت را از ۶۰ تا ۱۸۰ ضرب در دقیقه تنظیم کن.
• با «ساخت ملودی ساده» یکی از پنج حال‌وهوا را انتخاب کن؛ برنامه یک الگوی ملودی مناسب همان حال‌وهوا می‌سازد و می‌توانی فوراً آن را پخش کنی.
• برای ضبط ایده‌ای که در ذهنت است، «ضبط زمزمه یا آواز» را بزن؛ بعد از پایان ضبط، فایل به لایه‌های میکس اضافه می‌شود.
• در «میکس آهنگ» چند فایل صوتی انتخاب کن و صدای هرکدام را جدا تنظیم کن؛ می‌توانی لایه‌ها را حذف و متوقف کنی.
• در میکسر، ملودی، بیس، ریتم و ساز پس‌زمینهٔ آزمایشی هم قابل تنظیم‌اند؛ حالت «همه سازها» پیانو، سینتی، فلوت، گیتار کلاسیک، گیتار آکوستیک، گیتار برقی، تار و ویولن را در تنظیم نمونه به کار می‌گیرد.

ذخیره و انتقال
• از «ذخیره / بازیابی پروژه» برای ذخیرهٔ تنظیمات پروژه در فایل JSON یا بازیابی آن استفاده کن.
• از «پشتیبان برای انتقال به گوشی دیگر» یک بستهٔ ZIP شامل فایل‌های صوتی واردشده و تنظیمات بساز؛ آن را به گوشی جدید منتقل و از منوی پروژه بازیابی کن.
• «خروجی WAV» ملودی، بیس، ریتم و ساز پس‌زمینهٔ تولیدشده در برنامه را با تنظیمات صدای فعلی در یک فایل ترکیب می‌کند.
• خروجی گرفتن از میکس چندفایلی به‌صورت یک آهنگ واحد، خروجی MP3، هماهنگ‌سازی دقیق لایه‌ها و ابزارهای حرفه‌ای ویرایش هنوز در مراحل بعدی هستند.

حریم خصوصی و اینترنت
• انتخاب فایل با انتخاب‌گر امن اندروید انجام می‌شود.
• اجازهٔ میکروفون فقط برای ضبط زمزمه/آواز لازم است.
• ساخت ملودی آزمایشی آفلاین است. سرویس‌های هوش مصنوعی برای تغییر صدای خواننده، در صورت افزوده‌شدن، ممکن است اینترنت بخواهند.

وضعیت نسخهٔ فعلی
این نسخه آزمایشی است و هنوز روی گوشی واقعی آزمایش نشده. قابلیت‌های ضبط، بازیابی و بستهٔ انتقال باید روی دستگاه بررسی شوند. خروجی WAV فعلاً سازهای داخلی تولیدشده را ترکیب می‌کند، اما فایل‌های صوتی واردشده از گوشی را شامل نمی‌شود. خروجی MP3، افکت‌های حرفه‌ای، تبدیل زمزمه به نت و ابزارهای هوش مصنوعی برای صدای خواننده هنوز آماده نیستند. قابلیت‌های صدای خوانندهٔ شناخته‌شده فقط باید با رضایت و مجوز مناسب استفاده شوند. لطفاً قبل از استفادهٔ مهم، از فایل‌ها نسخهٔ پشتیبان نگه دار.
"""
        AlertDialog.Builder(this).setTitle("راهنمای برنامه").setMessage(guide)
            .setPositiveButton("متوجه شدم", null).show()
    }

    private fun showMelodyBuilder() {
        val moods = arrayOf("شاد", "غمگین", "نوستالژیک", "پرانرژی", "آرام")
        val selected = moods.indexOf(currentMood).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("✨ ساخت ملودی")
            .setSingleChoiceItems(moods, selected) { dialog, which ->
                currentMood = moods[which]
                generatedMelody = melodyForMood(currentMood)
                dialog.dismiss()
                refreshMoodLabel()
                refreshSoundLabel()
                Toast.makeText(this, "ملودی $currentMood ساخته شد؛ حالا «پخش ملودی» را بزن.", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun melodyForMood(mood: String): DoubleArray = when (mood) {
        "غمگین" -> doubleArrayOf(293.66, 261.63, 246.94, 220.00, 246.94, 261.63, 293.66, 261.63)
        "نوستالژیک" -> doubleArrayOf(329.63, 392.00, 440.00, 392.00, 329.63, 293.66, 261.63, 293.66)
        "پرانرژی" -> doubleArrayOf(392.00, 440.00, 493.88, 523.25, 493.88, 440.00, 523.25, 587.33)
        "آرام" -> doubleArrayOf(261.63, 293.66, 329.63, 392.00, 329.63, 293.66, 261.63, 246.94)
        else -> doubleArrayOf(261.63, 329.63, 392.00, 329.63, 293.66, 329.63, 440.00, 392.00)
    }

    private fun showRhythmBuilder() {
        val rhythms = arrayOf("پاپ ساده", "چهار ضربی", "آرام", "پرانرژی")
        val selected = rhythms.indexOf(rhythmStyle).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("🥁 انتخاب ریتم")
            .setSingleChoiceItems(rhythms, selected) { dialog, which ->
                rhythmStyle = rhythms[which]
                refreshSoundLabel()
                Toast.makeText(this, "ریتم «$rhythmStyle» انتخاب شد.", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.setNegativeButton("لغو", null).show()
    }

    private fun showInstrumentBuilder() {
        val instruments = arrayOf("همه سازها", "پیانو", "سینتی", "فلوت", "گیتار کلاسیک", "گیتار آکوستیک", "گیتار برقی", "تار", "ویولن")
        val selected = instruments.indexOf(melodyInstrument).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("🎹 ساز ملودی")
            .setSingleChoiceItems(instruments, selected) { dialog, which ->
                melodyInstrument = instruments[which]
                refreshSoundLabel()
                Toast.makeText(this, "ساز «$melodyInstrument» انتخاب شد.", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.setNegativeButton("لغو", null).show()
    }

    private fun refreshSoundLabel() {
        val root = window.decorView
        fun visit(group: ViewGroup) {
            for (i in 0 until group.childCount) {
                val child = group.getChildAt(i)
                if (child is TextView && child.tag == "sound_label") child.text = "ریتم: $rhythmStyle   |   سازها: $melodyInstrument"
                if (child is ViewGroup) visit(child)
            }
        }
        if (root is ViewGroup) visit(root)
    }

    private fun refreshMoodLabel() {
        val root = window.decorView
        fun visit(group: ViewGroup) {
            for (i in 0 until group.childCount) {
                val child = group.getChildAt(i)
                if (child is TextView && child.tag == "mood_label") child.text = "حال‌وهوا: $currentMood"
                if (child is ViewGroup) visit(child)
            }
        }
        if (root is ViewGroup) visit(root)
    }

    private fun showProjectMenu() {
        AlertDialog.Builder(this).setTitle("پروژهٔ آهنگ")
            .setItems(arrayOf("ذخیرهٔ تنظیمات پروژه…", "بازیابی پروژهٔ تنظیمات…", "خروجی WAV از میکس سازهای داخلی…", "بازیابی بستهٔ پشتیبان ZIP…")) { _, which ->
                when (which) {
                    0 -> saveProject()
                    1 -> openProject()
                    2 -> exportMixWav()
                    3 -> restoreTransferBackup()
                }
            }.show()
    }

    private fun projectJson(): JSONObject {
        val tracks = JSONArray()
        importedLayers.forEach { layer ->
            tracks.put(JSONObject().put("uri", layer.uri.toString()).put("name", layer.name).put("gain", layer.gain.toDouble()))
        }
        return JSONObject().put("format", "hakan-music-studio-project")
            .put("version", 4).put("bpm", bpm).put("volume", volume).put("mood", currentMood).put("rhythm", rhythmStyle).put("instrument", melodyInstrument).put("melody", JSONArray(generatedMelody.toList()))
            .put("melodyGain", melodyGain).put("bassGain", bassGain)
            .put("drumsGain", drumsGain).put("padGain", padGain).put("tracks", tracks)
    }

    private fun saveProject() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "HakanMusicProject.json")
        }
        startActivityForResult(intent, REQUEST_SAVE_PROJECT)
    }

    private fun openProject() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
        }
        startActivityForResult(intent, REQUEST_OPEN_PROJECT)
    }

    private fun applyProjectJson(json: JSONObject) {
        bpm = json.optInt("bpm", 120).coerceIn(60, 180)
        volume = json.optDouble("volume", 0.75).coerceIn(0.0, 1.0)
        currentMood = json.optString("mood", "شاد").ifBlank { "شاد" }
        rhythmStyle = json.optString("rhythm", "پاپ ساده").ifBlank { "پاپ ساده" }
        melodyInstrument = json.optString("instrument", "همه سازها").ifBlank { "همه سازها" }
        val savedMelody = json.optJSONArray("melody")
        if (savedMelody != null && savedMelody.length() >= 4) {
            generatedMelody = DoubleArray(savedMelody.length()) { i -> savedMelody.optDouble(i, 261.63).coerceIn(65.0, 1046.0) }
        }
        melodyGain = json.optDouble("melodyGain", 0.85).coerceIn(0.0, 1.0)
        bassGain = json.optDouble("bassGain", 0.45).coerceIn(0.0, 1.0)
        drumsGain = json.optDouble("drumsGain", 0.35).coerceIn(0.0, 1.0)
        padGain = json.optDouble("padGain", 0.25).coerceIn(0.0, 1.0)
        importedLayers.forEach { releaseLayer(it) }
        importedLayers.clear()
        val tracks = json.optJSONArray("tracks") ?: JSONArray()
        var restored = 0
        for (i in 0 until tracks.length()) {
            val item = tracks.optJSONObject(i) ?: continue
            val rawUri = item.optString("uri")
            if (rawUri.startsWith("backup:")) continue
            val uri = runCatching { Uri.parse(rawUri) }.getOrNull() ?: continue
            if (uri.scheme == "content" && importedLayers.none { it.uri == uri }) {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                importedLayers.add(AudioLayer(uri, item.optString("name", "فایل صوتی"), item.optDouble("gain", 0.8).toFloat().coerceIn(0f, 1f)))
                restored++
            }
        }
        Toast.makeText(this, "تنظیمات بازیابی شد. $restored فایل قابل‌دسترسی اضافه شد؛ برای انتقال کامل بین گوشی‌ها از بستهٔ ZIP استفاده کن.", Toast.LENGTH_LONG).show()
        buildScreen()
    }

    private fun toggleRecording() {
        if (isRecording) {
            try {
                recorder?.stop()
                val file = recordingFile
                recorder?.release(); recorder = null; isRecording = false
                if (file != null && file.exists() && file.length() > 1000) {
                    importedLayers.add(AudioLayer(Uri.fromFile(file), "زمزمهٔ ضبط‌شده ${importedLayers.size + 1}"))
                    Toast.makeText(this, "ضبط ذخیره شد و به میکسر اضافه شد.", Toast.LENGTH_LONG).show()
                    if (mixerDialog?.isShowing == true) { mixerDialog?.dismiss(); showMixer() }
                } else Toast.makeText(this, "ضبط کامل نشد؛ دوباره امتحان کن.", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                try { recorder?.release() } catch (_: Exception) {}
                recorder = null; isRecording = false
                Toast.makeText(this, "ضبط متوقف شد، اما فایل قابل استفاده ساخته نشد.", Toast.LENGTH_LONG).show()
            }
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestMicrophonePermission(); return
        }
        try {
            val file = File(filesDir, "humming_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100); r.setAudioEncodingBitRate(128000)
            r.setOutputFile(file.absolutePath); r.prepare(); r.start()
            recorder = r; recordingFile = file; isRecording = true
            AlertDialog.Builder(this).setTitle("🎙 ضبط در حال انجام است")
                .setMessage("حالا ملودی‌ات را زمزمه کن یا آواز بخوان. برای پایان ضبط، دکمهٔ زیر را بزن.")
                .setCancelable(false)
                .setPositiveButton("■ پایان ضبط") { _, _ -> toggleRecording() }
                .show()
        } catch (_: Exception) {
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null; isRecording = false
            Toast.makeText(this, "شروع ضبط ممکن نشد. اجازهٔ میکروفون و فضای خالی را بررسی کن.", Toast.LENGTH_LONG).show()
        }
    }

    private fun createTransferBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "HakanMusicStudio-Backup.zip")
        }
        startActivityForResult(intent, REQUEST_CREATE_BACKUP)
    }

    private fun restoreTransferBackup() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
        }
        startActivityForResult(intent, REQUEST_RESTORE_BACKUP)
    }

    private fun writeZipBackup(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { output ->
                ZipOutputStream(BufferedOutputStream(output)).use { zip ->
                    val manifest = projectJson()
                    val portableTracks = manifest.optJSONArray("tracks") ?: JSONArray()
                    importedLayers.forEachIndexed { index, layer ->
                        val trackInfo = portableTracks.optJSONObject(index)
                        trackInfo?.put("uri", "backup:audio/${index}_${safeFileName(layer.name)}")
                    }
                    zip.putNextEntry(ZipEntry("project.json")); zip.write(manifest.toString(2).toByteArray(Charsets.UTF_8)); zip.closeEntry()
                    importedLayers.forEachIndexed { index, layer ->
                        try {
                            zip.putNextEntry(ZipEntry("audio/${index}_${safeFileName(layer.name)}"))
                            openLayerInput(layer)?.use { input -> input.copyTo(zip) }
                            zip.closeEntry()
                        } catch (_: Exception) { runCatching { zip.closeEntry() } }
                    }
                }
            } ?: throw IllegalStateException("output unavailable")
            Toast.makeText(this, "بستهٔ پشتیبان ساخته شد. آن را به گوشی جدید منتقل کن.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "ساخت پشتیبان ناموفق بود؛ فضای خالی و محل ذخیره را بررسی کن.", Toast.LENGTH_LONG).show()
        }
    }

    private fun readZipBackup(uri: Uri) {
        try {
            var project: JSONObject? = null
            val extracted = mutableListOf<Pair<File, String>>()
            contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory && entry.name == "project.json") {
                            project = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                        } else if (!entry.isDirectory && entry.name.startsWith("audio/") && !entry.name.contains("..")) {
                            val file = File(filesDir, "restored_${System.currentTimeMillis()}_${File(entry.name).name}")
                            FileOutputStream(file).use { zip.copyTo(it) }
                            extracted.add(file to File(entry.name).name)
                        }
                        zip.closeEntry(); entry = zip.nextEntry
                    }
                }
            }
            val json = project ?: throw IllegalArgumentException("project.json missing")
            val trackManifest = json.optJSONArray("tracks") ?: JSONArray()
            applyProjectJson(json)
            extracted.forEach { (file, name) ->
                val match = (0 until trackManifest.length()).mapNotNull { trackManifest.optJSONObject(it) }
                    .firstOrNull { it.optString("uri").endsWith(name) }
                importedLayers.add(AudioLayer(Uri.fromFile(file), name, match?.optDouble("gain", 0.8)?.toFloat()?.coerceIn(0f, 1f) ?: 0.8f))
            }
            Toast.makeText(this, "پشتیبان بازیابی شد؛ ${extracted.size} فایل صوتی اضافه شد.", Toast.LENGTH_LONG).show()
            buildScreen()
        } catch (_: Exception) {
            Toast.makeText(this, "این فایل پشتیبان معتبر نیست یا قابل خواندن نیست.", Toast.LENGTH_LONG).show()
        }
    }

    private fun safeFileName(name: String): String = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "audio.m4a" }

    private fun openLayerInput(layer: AudioLayer) = if (layer.uri.scheme == "file") {
        layer.uri.path?.let { FileInputStream(File(it)) }
    } else {
        contentResolver.openInputStream(layer.uri)
    }

    private fun restoreAutoProject() {
        val file = File(filesDir, "autosave_project.json")
        if (!file.exists()) return
        runCatching { applyProjectJson(JSONObject(file.readText(Charsets.UTF_8))) }
            .onFailure { Toast.makeText(this, "بازیابی خودکار پروژه انجام نشد؛ فایل‌های اصلی را بررسی کن.", Toast.LENGTH_LONG).show() }
    }

    private fun saveAutoProject() {
        runCatching { File(filesDir, "autosave_project.json").writeText(projectJson().toString(), Charsets.UTF_8) }
    }

    override fun onPause() {
        saveAutoProject()
        super.onPause()
    }

    private fun exportMixWav() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, "Hakan-Mix.wav")
        }
        startActivityForResult(intent, REQUEST_EXPORT_WAV)
    }

    /** Render generated instruments and imported audio layers into a mono PCM WAV. */
    private fun writeDemoWav(uri: Uri) {
        Toast.makeText(this, "در حال ترکیب سازها و فایل‌های صوتی…", Toast.LENGTH_SHORT).show()
        thread(name = "hakan-wav-render") {
            try {
                val sampleRate = 22050
                val frequencies = generatedMelody.copyOf()
                val tempo = bpm.coerceIn(60, 180)
                val master = volume.coerceIn(0.0, 1.0)
                val mGain = melodyGain.coerceIn(0.0, 1.0)
                val bGain = bassGain.coerceIn(0.0, 1.0)
                val dGain = drumsGain.coerceIn(0.0, 1.0)
                val pGain = padGain.coerceIn(0.0, 1.0)
                val samplesPerBeat = (sampleRate * 60.0 / tempo).toInt().coerceAtLeast(1)
                val synth = ShortArray(samplesPerBeat * frequencies.size * 2)
                var pos = 0
                repeat(2) {
                    frequencies.forEachIndexed { beat, freq ->
                        val beatSeconds = samplesPerBeat.toDouble() / sampleRate
                        val bassFreq = if (beat % 2 == 0) 130.81 else 98.00
                        for (i in 0 until samplesPerBeat) {
                            val t = i.toDouble() / sampleRate
                            val melodyEnv = minOf(1.0, t / 0.02) * kotlin.math.exp(-3.0 * t / beatSeconds)
                            val bassEnv = kotlin.math.exp(-2.2 * t / beatSeconds)
                            val padEnv = minOf(1.0, t / 0.12) * kotlin.math.exp(-0.9 * t / beatSeconds)
                            val kick = if (beat % 2 == 0) sin(2 * PI * (58.0 - 20.0 * t) * t) * kotlin.math.exp(-18.0 * t) else 0.0
                            val snare = if (beat % 2 == 1) sin(2 * PI * 180.0 * t) * kotlin.math.exp(-24.0 * t) else 0.0
                            val melody = (sin(2 * PI * freq * t) + 0.25 * sin(4 * PI * freq * t)) * melodyEnv * mGain
                            val bass = sin(2 * PI * bassFreq * t) * bassEnv * bGain
                            val pad = (sin(2 * PI * 261.63 * t) + sin(2 * PI * 329.63 * t) + sin(2 * PI * 392.00 * t)) / 3.0 * padEnv * pGain
                            val drums = (kick * 0.9 + snare * 0.45) * dGain
                            synth[pos++] = ((melody + bass + pad + drums) * 9000 * master).toInt().coerceIn(-32768, 32767).toShort()
                        }
                    }
                }

                val decodedLayers = mutableListOf<Pair<ShortArray, Float>>()
                importedLayers.toList().forEach { layer ->
                    val samples = decodeAudioToMono22050(layer.uri)
                    if (samples.isNotEmpty()) decodedLayers.add(samples to layer.gain.coerceIn(0f, 1f))
                }
                val totalLength = maxOf(synth.size, decodedLayers.maxOfOrNull { it.first.size } ?: 0)
                val mixed = FloatArray(totalLength)
                for (i in synth.indices) mixed[i] += synth[i].toFloat()
                decodedLayers.forEach { (samples, gain) ->
                    for (i in samples.indices) mixed[i] += samples[i].toFloat() * gain * master.toFloat()
                }
                val pcm = ShortArray(totalLength) { i -> mixed[i].roundToInt().coerceIn(-32768, 32767).toShort() }
                contentResolver.openOutputStream(uri)?.use { out ->
                    val dataSize = pcm.size * 2
                    DataOutputStream(BufferedOutputStream(out)).use { d ->
                        fun ascii(s: String) = s.forEach { d.writeByte(it.code) }
                        fun le16(v: Int) { d.writeByte(v and 255); d.writeByte((v shr 8) and 255) }
                        fun le32(v: Int) { le16(v and 0xffff); le16((v shr 16) and 0xffff) }
                        ascii("RIFF"); le32(36 + dataSize); ascii("WAVE"); ascii("fmt "); le32(16)
                        le16(1); le16(1); le32(sampleRate); le32(sampleRate * 2); le16(2); le16(16)
                        ascii("data"); le32(dataSize)
                        pcm.forEach { le16(it.toInt() and 0xffff) }
                    }
                } ?: throw IllegalStateException("no output")
                runOnUiThread { Toast.makeText(this, "فایل WAV شامل سازهای داخلی و ${decodedLayers.size} لایهٔ صوتی ذخیره شد.", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "ساخت WAV ناموفق بود. ممکن است قالب یکی از فایل‌ها پشتیبانی نشود.", Toast.LENGTH_LONG).show() }
            }
        }
    }

    /** Decode a selected audio document through Android's on-device codec, then resample to mono 22.05 kHz. */
    private fun decodeAudioToMono22050(uri: Uri): ShortArray {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(this, uri, null)
            var audioTrack = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { audioTrack = i; format = f; break }
            }
            if (audioTrack < 0 || format == null) throw IllegalArgumentException("No audio track")
            extractor.selectTrack(audioTrack)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: throw IllegalArgumentException("No MIME")
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            val source = ArrayList<Float>()
            var inputDone = false
            var outputDone = false
            var sourceRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            while (!outputDone && source.size < sourceRate * 180) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10000)
                    if (inputIndex >= 0) {
                        val input = codec.getInputBuffer(inputIndex) ?: continue
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val outputIndex = codec.dequeueOutputBuffer(info, 10000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sourceRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (Build.VERSION.SDK_INT >= 24 && of.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = of.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outputIndex >= 0) {
                        val output = codec.getOutputBuffer(outputIndex)
                        if (output != null && info.size > 0) {
                            output.position(info.offset); output.limit(info.offset + info.size)
                            output.order(ByteOrder.LITTLE_ENDIAN)
                            val frameBytes = channels * if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) 4 else 2
                            while (output.remaining() >= frameBytes && source.size < sourceRate * 180) {
                                var sum = 0f
                                repeat(channels) {
                                    sum += if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) output.float else output.short / 32768f
                                }
                                source.add(sum / channels.coerceAtLeast(1))
                            }
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
            if (source.isEmpty()) return ShortArray(0)
            val outputCount = (source.size.toDouble() * 22050.0 / sourceRate).roundToInt().coerceAtLeast(1)
            return ShortArray(outputCount) { i ->
                val at = i.toDouble() * sourceRate / 22050.0
                val left = at.toInt().coerceIn(0, source.lastIndex)
                val right = (left + 1).coerceAtMost(source.lastIndex)
                val frac = (at - left).toFloat().coerceIn(0f, 1f)
                ((source[left] * (1f - frac) + source[right] * frac) * 32767f).roundToInt().coerceIn(-32768, 32767).toShort()
            }
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun showSettings() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(12), dp(22), dp(8))
        }
        content.addView(TextView(this).apply {
            text = "تنظیم صدای ملودی"; textSize = 16f
        }, match(WRAP))
        val volumeLabel = TextView(this).apply { text = "بلندی صدا: ${(volume * 100).toInt().toPersianDigits()}٪" }
        content.addView(volumeLabel, match(WRAP))
        content.addView(SeekBar(this).apply {
            max = 100; progress = (volume * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    volume = progress / 100.0
                    volumeLabel.text = "بلندی صدا: ${progress.toPersianDigits()}٪"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }, match(WRAP))
        content.addView(TextView(this).apply {
            text = "مجوز میکروفون برای ضبط صدا درخواست می‌شود. برای انتخاب یا ذخیرهٔ فایل‌ها، نسخهٔ کامل از انتخاب‌گر امن فایل اندروید استفاده خواهد کرد؛ دسترسی غیرضروری به کل گوشی گرفته نمی‌شود."
            textSize = 14f; setPadding(0, dp(12), 0, 0)
        }, match(WRAP))
        AlertDialog.Builder(this)
            .setTitle("تنظیمات برنامه")
            .setView(content)
            .setPositiveButton("درخواست مجوز میکروفون") { _, _ -> requestMicrophonePermission() }
            .setNegativeButton("بستن", null)
            .setNeutralButton("خروج از برنامه") { _, _ -> confirmExit() }
            .show()
    }


    private fun showMixer() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        mixerContent = content
        content.addView(TextView(this).apply {
            text = "لایه‌های آماده را تنظیم کن یا چند فایل صوتی از گوشی انتخاب کن و هم‌زمان پخش کن."
            textSize = 14f; setTextColor(Color.DKGRAY)
        }, match(WRAP))
        val importButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        importButtons.addView(Button(this@MainActivity).apply {
            text = "＋ افزودن فایل صوتی"
            setOnClickListener { chooseAudioFiles() }
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(4) })
        importButtons.addView(Button(this@MainActivity).apply {
            text = "▶ پخش فایل‌ها"
            setOnClickListener { playImportedLayers() }
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(4) })
        content.addView(importButtons, match(WRAP))
        content.addView(Button(this).apply {
            text = "■ توقف فایل‌ها"
            setOnClickListener { stopImportedLayers() }
        }, match(dp(44)))
        content.addView(TextView(this).apply {
            text = "فایل‌های انتخاب‌شده (هر فایل یک لایه):"
            textSize = 16f; setTextColor(Color.DKGRAY); setPadding(0, dp(8), 0, dp(4))
        }, match(WRAP))
        renderImportedLayers(content)
        fun channel(label: String, initial: Double, applyGain: (Double) -> Unit) {
            val title = TextView(this).apply { text = "$label: ${(initial * 100).toInt().toPersianDigits()}٪"; textSize = 16f }
            content.addView(title, match(WRAP))
            content.addView(SeekBar(this).apply {
                max = 100; progress = (initial * 100).toInt(); contentDescription = label
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                        applyGain(progress / 100.0)
                        title.text = "$label: ${progress.toPersianDigits()}٪"
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }, match(WRAP))
        }
        channel("🎹 ملودی", melodyGain) { melodyGain = it }
        channel("🎸 بیس", bassGain) { bassGain = it }
        channel("🥁 ریتم", drumsGain) { drumsGain = it }
        channel("🌌 ساز پس‌زمینه", padGain) { padGain = it }
        val scroll = ScrollView(this).apply { addView(content) }
        mixerDialog = AlertDialog.Builder(this)
            .setTitle("🎚 میکسر آهنگ")
            .setView(scroll)
            .setPositiveButton("تمام") { _, _ -> }
            .setNeutralButton("بازنشانی لایه‌ها") { _, _ ->
                melodyGain = 0.85; bassGain = 0.45; drumsGain = 0.35; padGain = 0.25
                showMixer()
            }
            .create()
        mixerDialog?.setOnDismissListener { mixerContent = null; mixerDialog = null }
        mixerDialog?.show()
    }

    private fun chooseAudioFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_AUDIO_FILES)
    }

    @Deprecated("Use the system document picker result for selecting audio tracks")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val selectedUri = data.data
        if (requestCode != REQUEST_AUDIO_FILES && selectedUri == null) return
        when (requestCode) {
            REQUEST_SAVE_PROJECT -> { selectedUri?.let { u ->
                val result = runCatching { contentResolver.openOutputStream(u)?.use { it.write(projectJson().toString(2).toByteArray(Charsets.UTF_8)) } ?: error("no output") }
                if (result.isSuccess) Toast.makeText(this, "پروژه ذخیره شد.", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this, "ذخیرهٔ پروژه ناموفق بود.", Toast.LENGTH_LONG).show()
            }; return }
            REQUEST_OPEN_PROJECT -> { selectedUri?.let { u -> runCatching { contentResolver.openInputStream(u)?.bufferedReader()?.use { applyProjectJson(JSONObject(it.readText())) } }.onFailure { Toast.makeText(this, "خواندن پروژه ناموفق بود.", Toast.LENGTH_LONG).show() } }; return }
            REQUEST_CREATE_BACKUP -> { selectedUri?.let { writeZipBackup(it) }; return }
            REQUEST_RESTORE_BACKUP -> { selectedUri?.let { readZipBackup(it) }; return }
            REQUEST_EXPORT_WAV -> { selectedUri?.let { writeDemoWav(it) }; return }
        }
        if (requestCode != REQUEST_AUDIO_FILES) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } ?: data.data?.let { uris.add(it) }
        var added = 0
        uris.forEach { uri ->
            if (importedLayers.none { it.uri == uri }) {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                importedLayers.add(AudioLayer(uri, queryDisplayName(uri)))
                added++
            }
        }
        Toast.makeText(this, if (added > 0) "$added فایل صوتی اضافه شد." else "فایلی اضافه نشد.", Toast.LENGTH_LONG).show()
        mixerContent?.let { content ->
            // Rebuild the mixer so the new track controls appear immediately.
            mixerDialog?.dismiss()
            showMixer()
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        var name = "فایل صوتی"
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) name = cursor.getString(index) ?: name
            }
        } catch (_: Exception) { }
        finally { cursor?.close() }
        return name
    }

    private fun renderImportedLayers(content: LinearLayout) {
        if (importedLayers.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "هنوز فایلی انتخاب نشده است. با دکمهٔ بالا فایل‌های MP3، WAV یا قالب‌های پشتیبانی‌شدهٔ گوشی را انتخاب کن."
                textSize = 13f; setTextColor(Color.DKGRAY); setPadding(0, dp(4), 0, dp(8))
            }, match(WRAP))
            return
        }
        importedLayers.toList().forEachIndexed { index, layer ->
            content.addView(TextView(this).apply {
                text = "${index + 1}. ${layer.name}"
                textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0, dp(6), 0, 0)
            }, match(WRAP))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val gain = SeekBar(this).apply {
                max = 100; progress = (layer.gain * 100).toInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                        layer.gain = progress / 100f
                        layer.player?.setVolume(layer.gain, layer.gain)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            row.addView(gain, LinearLayout.LayoutParams(0, dp(42), 1f))
            row.addView(Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    releaseLayer(layer)
                    importedLayers.remove(layer)
                    mixerDialog?.dismiss()
                    showMixer()
                }
            }, LinearLayout.LayoutParams(dp(64), dp(42)))
            content.addView(row, match(WRAP))
        }
    }

    private fun playImportedLayers() {
        if (importedLayers.isEmpty()) {
            Toast.makeText(this, "اول فایل صوتی اضافه کن.", Toast.LENGTH_SHORT).show(); return
        }
        importedLayers.forEach { releaseLayer(it) }
        var preparedCount = 0
        importedLayers.forEach { layer ->
            try {
                val player = MediaPlayer()
                layer.player = player
                player.setDataSource(this, layer.uri)
                player.setVolume(layer.gain, layer.gain)
                player.setOnPreparedListener { prepared ->
                    preparedCount++
                    // Start each track when ready; the system decoder supports common phone audio formats.
                    prepared.start()
                    if (preparedCount == importedLayers.size) Toast.makeText(this, "پخش لایه‌های صوتی آغاز شد.", Toast.LENGTH_SHORT).show()
                }
                player.setOnErrorListener { mp, _, _ ->
                    Toast.makeText(this, "پخش «${layer.name}» ممکن نیست؛ قالب فایل را بررسی کن.", Toast.LENGTH_LONG).show()
                    try { mp.release() } catch (_: Exception) {}
                    layer.player = null
                    true
                }
                player.prepareAsync()
            } catch (_: Exception) {
                releaseLayer(layer)
                Toast.makeText(this, "بازکردن «${layer.name}» ناموفق بود.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun stopImportedLayers() {
        importedLayers.forEach { layer ->
            try { layer.player?.pause(); layer.player?.seekTo(0) } catch (_: Exception) {}
        }
    }

    private fun releaseLayer(layer: AudioLayer) {
        try { layer.player?.stop() } catch (_: Exception) {}
        try { layer.player?.release() } catch (_: Exception) {}
        layer.player = null
    }

    private fun requestFirstRunPermissionsIfNeeded() {
        val prefs = getSharedPreferences("app_settings", MODE_PRIVATE)
        if (!prefs.getBoolean("permission_prompt_shown", false)) {
            prefs.edit().putBoolean("permission_prompt_shown", true).apply()
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                AlertDialog.Builder(this)
                    .setTitle("اجازهٔ دسترسی به میکروفون")
                    .setMessage("برای قابلیت ضبط صدای خودت در نسخه‌های بعدی، اجازهٔ میکروفون لازم است. این اجازه بدون تأیید تو فعال نمی‌شود.")
                    .setPositiveButton("ادامه") { _, _ -> requestMicrophonePermission() }
                    .setNegativeButton("فعلاً نه", null)
                    .show()
            }
        }
    }

    private fun requestMicrophonePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MICROPHONE)
        } else {
            Toast.makeText(this, "مجوز میکروفون قبلاً داده شده است.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MICROPHONE) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            Toast.makeText(this, if (granted) "مجوز میکروفون فعال شد." else "بدون مجوز میکروفون هم می‌توانی ملودی را پخش کنی.", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setMessage("از برنامه خارج می‌شوی؟")
            .setNegativeButton("ادامهٔ کار", null)
            .setPositiveButton("خروج") { _, _ -> stopMelody(); finish() }
            .show()
    }

    @Deprecated("Double-back exit is retained for compatibility with older Android devices")
    override fun onBackPressed() {
        val now = System.currentTimeMillis()
        if (now - lastBackPress < 2000L) {
            stopMelody()
            finish()
        } else {
            lastBackPress = now
            Toast.makeText(this, "برای خروج، دوباره دکمهٔ بازگشت را بزنید.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun playMelody() {
        stopMelody(false)
        playing.set(true)
        status.text = "در حال پخش…"
        val tempo = bpm
        thread(name = "offline-melody") {
            val sampleRate = 22050
            val minBuffer = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val audio = AudioTrack(AudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuffer, 4096), AudioTrack.MODE_STREAM)
            track = audio
            val frequencies = generatedMelody
            val samplesPerBeat = (sampleRate * 60.0 / tempo).toInt()
            try {
                audio.play()
                repeat(2) {
                    for (beat in frequencies.indices) {
                        if (!playing.get()) break
                        val freq = frequencies[beat]
                        val pcm = ShortArray(samplesPerBeat)
                        val beatSeconds = samplesPerBeat.toDouble() / sampleRate
                        val bassFreq = if (beat % 2 == 0) 130.81 else 98.00
                        for (i in pcm.indices) {
                            val t = i.toDouble() / sampleRate
                            val melodyEnv = minOf(1.0, t / 0.02) * kotlin.math.exp(-3.0 * t / beatSeconds)
                            val bassEnv = kotlin.math.exp(-2.2 * t / beatSeconds)
                            val padEnv = minOf(1.0, t / 0.12) * kotlin.math.exp(-0.9 * t / beatSeconds)
                            val beatInBar = beat % 4
                            val kickOn = when (rhythmStyle) {
                                "آرام" -> beatInBar == 0
                                "پرانرژی" -> beatInBar == 0 || beatInBar == 2 || beatInBar == 3
                                "چهار ضربی" -> beatInBar == 0 || beatInBar == 2
                                else -> beatInBar == 0 || beatInBar == 2
                            }
                            val snareOn = when (rhythmStyle) {
                                "آرام" -> beatInBar == 2
                                "پرانرژی" -> beatInBar == 1 || beatInBar == 3
                                else -> beatInBar == 1 || beatInBar == 3
                            }
                            val kick = if (kickOn) sin(2 * PI * (58.0 - 20.0 * t) * t) * kotlin.math.exp(-18.0 * t) else 0.0
                            val snare = if (snareOn) sin(2 * PI * 180.0 * t) * kotlin.math.exp(-24.0 * t) else 0.0
                            // در حالت «همه سازها»، هر سه صدای ملودی هم‌زمان و با شدت متفاوت نواخته می‌شوند.
                            val pianoVoice = sin(2 * PI * freq * t) + 0.25 * sin(4 * PI * freq * t) + 0.10 * sin(6 * PI * freq * t)
                            val synthVoice = sin(2 * PI * freq * t) + 0.45 * sin(4 * PI * freq * t) + 0.20 * sin(6 * PI * freq * t)
                            val fluteVoice = sin(2 * PI * freq * t) + 0.08 * sin(4 * PI * freq * t)
                            // مدل‌های سادهٔ آفلاین برای رنگ‌های سازهای زهی و ایرانی؛ این‌ها سمپل واقعی نیستند.
                            val guitarClassical = sin(2 * PI * freq * t) + 0.16 * sin(3 * PI * freq * t) + 0.08 * sin(5 * PI * freq * t)
                            val guitarAcoustic = sin(2 * PI * freq * t) + 0.22 * sin(3 * PI * freq * t) + 0.12 * sin(5 * PI * freq * t)
                            val guitarElectric = sin(2 * PI * freq * t) + 0.34 * sin(3 * PI * freq * t) + 0.20 * sin(5 * PI * freq * t) + 0.10 * sin(7 * PI * freq * t)
                            val tarVoice = sin(2 * PI * freq * t) + 0.30 * sin(3 * PI * freq * t) + 0.18 * sin(5 * PI * freq * t) + 0.07 * sin(7 * PI * freq * t)
                            val violinVoice = sin(2 * PI * freq * t) + 0.38 * sin(2 * PI * freq * 2.0 * t) + 0.16 * sin(2 * PI * freq * 3.0 * t)
                            val melodyRaw = when (melodyInstrument) {
                                "سینتی" -> synthVoice
                                "فلوت" -> fluteVoice
                                "پیانو" -> pianoVoice
                                "گیتار کلاسیک" -> guitarClassical
                                "گیتار آکوستیک" -> guitarAcoustic
                                "گیتار برقی" -> guitarElectric
                                "تار" -> tarVoice
                                "ویولن" -> violinVoice
                                else -> pianoVoice * 0.18 + synthVoice * 0.12 + fluteVoice * 0.10 + guitarClassical * 0.13 + guitarAcoustic * 0.12 + guitarElectric * 0.10 + tarVoice * 0.12 + violinVoice * 0.13
                            }
                            val melody = melodyRaw * melodyEnv * melodyGain
                            // باس، پد و درام نیز بخشی از تنظیم کامل هستند و همیشه با ملودی هماهنگ می‌مانند.
                            val bass = sin(2 * PI * bassFreq * t) * bassEnv * bassGain
                            val pad = (sin(2 * PI * 261.63 * t) + sin(2 * PI * 329.63 * t) + sin(2 * PI * 392.00 * t)) / 3.0 * padEnv * padGain
                            val drums = (kick * 0.9 + snare * 0.45) * drumsGain
                            pcm[i] = ((melody + bass + pad + drums) * 9000 * volume).toInt().coerceIn(-32768, 32767).toShort()
                        }
                        var offset = 0
                        while (offset < pcm.size && playing.get()) {
                            val written = audio.write(pcm, offset, pcm.size - offset)
                            if (written <= 0) break
                            offset += written
                        }
                    }
                    if (playing.get()) Thread.sleep(180)
                }
            } catch (_: Exception) {
            } finally {
                try { audio.stop() } catch (_: Exception) {}
                audio.release()
                track = null
                playing.set(false)
                runOnUiThread { if (::status.isInitialized) status.text = "پایان ملودی؛ دوباره پخش کن." }
            }
        }
    }

    private fun stopMelody(updateStatus: Boolean = true) {
        playing.set(false)
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        if (updateStatus && ::status.isInitialized) status.text = "متوقف شد"
    }

    override fun onDestroy() {
        saveAutoProject()
        stopImportedLayers()
        stopMelody()
        if (isRecording) {
            try { recorder?.stop() } catch (_: Exception) {}
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null; isRecording = false
        }
        importedLayers.forEach { releaseLayer(it) }
        super.onDestroy()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun match(height: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)
    private fun Int.toPersianDigits() = toString().map { if (it in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")
    companion object {
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val REQUEST_MICROPHONE = 1001
        private const val REQUEST_AUDIO_FILES = 1002
        private const val REQUEST_SAVE_PROJECT = 1003
        private const val REQUEST_OPEN_PROJECT = 1004
        private const val REQUEST_CREATE_BACKUP = 1005
        private const val REQUEST_RESTORE_BACKUP = 1006
        private const val REQUEST_EXPORT_WAV = 1007
    }
}
